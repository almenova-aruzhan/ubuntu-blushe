#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
docker compose up -d --build
echo "Web: http://localhost:8080"
echo "API: http://localhost:8080/api/products"
