#!/bin/bash
DATE=$(date +%F_%H-%M)
docker exec blushe-db-1 mariadb-dump -uroot -p'RootPass_123!' blushe_db > backup_$DATE.sql
