/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: blushe_db
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `ingredients` text DEFAULT NULL,
  `skin_type` varchar(50) DEFAULT NULL,
  `concerns` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'Blushe Lipstick',4990.00,'Matte lipstick','2026-02-15 23:01:04','Oils, Vitamin E','all','dryness,lips'),
(2,'Blushe Blush',6990.00,'Soft pink blush','2026-02-16 06:47:18',NULL,NULL,NULL),
(3,'Blushe Gloss',3990.00,'Shiny gloss','2026-03-01 10:53:55',NULL,NULL,NULL),
(4,'Blushe Blush',6990.00,'Soft blush palette','2026-03-01 10:53:55',NULL,NULL,NULL),
(5,'Blushe Mascara',5490.00,'Volume mascara','2026-03-01 10:53:55',NULL,NULL,NULL),
(6,'Blushe Liner',2990.00,'Black eyeliner','2026-03-01 10:53:55',NULL,NULL,NULL),
(7,'Blushe Serum',8990.00,'Hydrating serum','2026-03-01 10:53:55',NULL,NULL,NULL),
(8,'Blushe SPF 50',7990.00,'Daily sunscreen','2026-03-01 10:53:55','uv filters, antioxidants','all','sun,prevention'),
(9,'Blushe Cleanser',4590.00,'Gentle face wash','2026-03-01 10:53:55','niacinamide, centella, tea tree','oily,combination','acne,pores,oil'),
(10,'Blushe Toner',4990.00,'Moisturizing toner','2026-03-01 10:53:55','hyaluronic acid, glycerin','dry,combination,sensitive','dehydration'),
(11,'Blushe Cream',6490.00,'Barrier repair cream','2026-03-01 10:53:55','panthenol, ceramides, squalane','dry,sensitive,combination','barrier,redness,dehydration'),
(12,'Blushe Lip Balm',2490.00,'Nourishing lip balm','2026-03-01 10:53:55','Oils, Vitamin E','all','dryness,lips');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-02 21:03:04
